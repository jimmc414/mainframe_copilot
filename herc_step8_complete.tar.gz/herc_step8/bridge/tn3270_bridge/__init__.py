"""TN3270 Bridge - JSON API for s3270 automation"""
__version__ = "1.0.0"